function Iout = extract ( I, d )

% number of rows and columns to add in pre-processing step
fill_rows = d * ceil( size(I, 1) / d ) - size( I, 1 );
fill_cols = d * ceil( size(I, 2) / d ) - size( I, 2 );

% pre-process
% fills matrix with rows and columns to that
% patch size divides evenly
if fill_rows ~= 0
    I = [I; repmat(I(size(I, 1), :, :), [fill_rows 1])];
end

if fill_cols ~= 0
    I = [I repmat(I(:, size(I, 2), :), [1 fill_cols])];
end

% preallocate result matrix FOR TEH SPEED
Iout = zeros(d^2, numel(I)/d^2);

% helper variable - indicates current Iout column
current = 1;

% extract features
% for every color channel
for d3 = 1:size(I, 3)
    for j = 0:size(I, 1) / d - 1
        for k = 0:size(I, 2) / d - 1
            % get a patch, vectorize it and throw it into the result matrix
            patch = I(j*d+1 : j*d+d, k*d+1 : k*d+d, d3);
            Iout(:, current) = patch(:);
            current = current+1;
        end
    end
end
end
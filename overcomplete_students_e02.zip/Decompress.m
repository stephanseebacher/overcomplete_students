function I_rec = Decompress ( I_comp )

% Your decompression code goes here!

I_almost = I_comp.U * I_comp.Zm;
I_shift = I_almost + repmat(I_comp.mu, 1, size(I_almost,2));

I_rec = reassemble(I_shift, I_comp.size);

%I_rec = I_comp.I; % this is just a stump to make the evaluation script run, replace it with your code!
end
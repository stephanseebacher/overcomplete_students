function I_comp = Compress ( I )

% SETTINGS ----------------------------------------------------------------
% For our baseline version, we decided to keep fixed values for d and k.
d = 20;
k = 100;
% -------------------------------------------------------------------------

% extract "features" == patches
X = extract( I, d );

% do PCA analysis
[mu, ~, U] = PCAanalyse( X );

% SANITY CHECK ------------------------------------------------------------
% If we get a really small picture, U is very small too, 
%  thus rank(U) could be smaller than k and k > rank(U) will
%  throw an 'Index exceeds matrix dimensions' error
k = min(rank(U), k);
% -------------------------------------------------------------------------

% subtract the mean
Xm = X - repmat(mu, 1, size( X, 2 ));

% factorization
U = U( :, 1:k );
Zm = U' * Xm;

% return some funny stuff that doesn't look like an image
I_comp.Zm = Zm;
I_comp.U = U;
I_comp.mu = mu;
I_comp.size = size(I);
end

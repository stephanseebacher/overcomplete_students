function [mu, lambda, U] = PCAanalyse(X)

% calculate empirical mean
mu = mean(X, 2);

% center the data
Xm = X - repmat(mu, 1, size(X,2));

% compute covariance matrix
Cov = cov(Xm');

% eigenvalue decomposition
[U, lambda] = eig(Cov);
lambda = diag(lambda);
[lambda, ind] = sort(lambda, 'descend');
U = U(:,ind);

end
